package ru.murea;

import java.net.IDN;
import java.util.Comparator;
import java.util.Arrays;

class Student
{
    private int IDNumber;
    private int GPA;

    public Student(int _IDNumber, int _GPA)
    {
        IDNumber = _IDNumber;
        GPA = _GPA;
    }

    public int getIDNumber()
    {
        return IDNumber;
    }
    public int getGPA()
    {
        return GPA;
    }

}

class SortingStudentsByID implements Comparator
{
    @Override
    public int compare(Object o1, Object o2)
    {
        return ((Student)o1).getIDNumber() - ((Student)o2).getIDNumber();
    }
}

class SortingStudentsByGPA implements Comparator
{
    @Override
    public int compare(Object o1, Object o2)
    {
        return ((Student)o2).getGPA() - ((Student)o1).getGPA();
    }
}


public class Main
{
    // Функция сортировки массива вставками
    public static void insertionSort(Student[] array, Comparator sort)
    {
        int b = array.length;
        int i, j;
        Student t;
        for (i = 0; i < b; i++)
        {
            t = array[i];
            for (j = i - 1; j >= 0 && sort.compare(array[j], t) > 0; j--)
            {
                array[j + 1] = array[j];
            }
            array[j + 1] = t;
        }
    }

    // Функция вывода массива
    public static void outputID(Student[] array)
    {
        for (int i = 0; i < array.length; i++)
        {
            System.out.println(array[i].getIDNumber());
        }
    }
    public static void outputGPA(Student[] array)
    {
        for (int i = 0; i < array.length; i++)
        {
            System.out.println(array[i].getGPA());
        }
    }

    // Сортировка слиянием
    public static void sortUnsorted(Student[] a, int lo, int hi, Comparator sort)
    {
        if (hi <= lo) return;
        int mid = lo + (hi - lo) / 2;
        sortUnsorted(a, lo, mid, sort);
        sortUnsorted(a, mid + 1, hi, sort);

        Student[] buf = Arrays.copyOf(a, a.length);

        for (int k = lo; k <= hi; k++)
        {
            buf[k] = a[k];
        }

        int i = lo, j = mid + 1;
        for (int k = lo; k <= hi; k++)
        {

            if (i > mid)
            {
                a[k] = buf[j];
                j++;
            }
            else if (j > hi)
            {
                a[k] = buf[i];
                i++;
            }
            else if (sort.compare(buf[j], buf[i]) > 0)
            {
                a[k] = buf[j];
                j++;
            }
            else
            {
                a[k] = buf[i];
                i++;
            }
        }
    }

    public static void mergeSort(Student[] array, Comparator sort)
    {
        sortUnsorted(array, 0, array.length - 1, sort);
    }

    // Быстрая сортировка
    public static void doQuickSort(Student[] array, int start, int end, Comparator sort)
    {
        if (start >= end) return;
        int i = start, j = end;
        int cur = i - (i - j) / 2;
        while (i < j)
        {
            while (i < cur && sort.compare(array[cur], array[i]) > 0)
            {
                i++;
            }
            while (j > cur && sort.compare(array[j], array[cur]) > 0)
            {
                j--;
            }
            if (i < j)
            {
                Student temp = array[i];
                array[i] = array[j];
                array[j] = temp;
                if (i == cur) cur = j;
                else if (j == cur) cur = i;
            }
        }
        doQuickSort(array, start, cur, sort);
        doQuickSort(array,cur + 1, end, sort);
    }

    public static void quickSort(Student[] array, Comparator sort)
    {
        doQuickSort(array, 0, array.length - 1, sort);
    }

    public static void main(String[] args)
    {
        SortingStudentsByGPA sortGPA = new SortingStudentsByGPA();
        SortingStudentsByID sortID = new SortingStudentsByID();
        int[] idArray = {1023, 1000, 1234, 1006, 1012, 1003, 1011, 1452, 1013, 1053, 1256, 1103, 1054, 1015, 1076, 1090};
        int[] GPAArray = {59, 80, 72, 60, 56, 68, 65, 73, 79, 64, 81, 89, 69, 57, 74, 62};
        Student[] students1 = new Student[idArray.length];
        Student[] students2 = new Student[idArray.length];
        Student[] students3 = new Student[idArray.length];
        for (int i = 0; i < students1.length; i++)
        {
            students1[i] = new Student(idArray[i], GPAArray[i]);
            students2[i] = new Student(idArray[i], GPAArray[i]);
            students3[i] = new Student(idArray[i], GPAArray[i]);
        }

        // Упражнение 1
        System.out.println("Сортировка вставками");
        insertionSort(students1, sortID);
        outputID(students1);

        // Упражнение 2
        System.out.println("\nБыстрая сортировка");
        quickSort(students2, sortGPA);
        outputGPA(students2);

        // Упражнение 3
        System.out.println("\nСортировка слиянием");
        mergeSort(students3, sortGPA);
        outputGPA(students3);
    }
}
