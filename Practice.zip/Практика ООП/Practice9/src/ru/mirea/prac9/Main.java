package ru.mirea.prac9;

import java.util.Scanner;

class Client
{
    private int INN;
    private String FIO;
    public Client(String _FIO, int _INN)
    {
        FIO = _FIO;
        INN = _INN;
    }
    private boolean nameCheck(String _FIO)
    {
        return FIO.equals(_FIO);
    }
    public boolean innCheck(String _FIO, int _INN) throws Exception {
        if (nameCheck(_FIO)){
            if (INN == _INN)
            {
                return true;
            }
            else throw new Exception("Incorrect INN");
        }
        else return false;
    }

    @Override
    public String toString() {
        return FIO + ' ' + INN;
    }
}

public class Main {
    public static void main(String[] args)
    {
        Client[] clients = new Client[6];

        clients[0] = new Client("Ivanov Ivan Ivanovich", 1001);
        clients[1] = new Client("Isaev Isa Isaevich", 1002);
        clients[2] = new Client("Sancho Jadon Semenovich", 1003);
        clients[3] = new Client("Rashford Marcus Alexeevich", 1004);
        clients[4] = new Client("Maldini Paolo Cezarevich", 1005);
        clients[5] = new Client("Messi Lionel Andreevich", 1006);

        Scanner scanner = new Scanner(System.in);
        String tempString;
        int tempInt;
        System.out.println("Введите данные клиента");
        tempString = scanner.nextLine();
        tempInt = scanner.nextInt();
        for (int i = 0; i < clients.length; i++)
        {
            try {
                if (clients[i].innCheck(tempString, tempInt))
                    System.out.println("ИНН совпадает");
            }
            catch (Exception E)
            {
                System.out.println("ИНН не совпадает");
            }
        }
    }
}
