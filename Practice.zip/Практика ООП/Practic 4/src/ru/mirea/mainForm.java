package ru.mirea;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class myWindow extends JFrame
{
    JPanel[] pnl = new JPanel[6];
    JLabel milanLabel = new JLabel();
    JLabel realLabel = new JLabel();
    JLabel score = new JLabel();
    JLabel infoWinner = new JLabel();
    JLabel infoLastGoal = new JLabel();
    JLabel milanGoal = new JLabel();
    JLabel realGoal = new JLabel();
    Font fnt = new Font("Arial", Font.BOLD, 60);
    public int milanGoals = 0;
    public int realGoals = 0;

    public void refreshScore(String lastScored)
    {
        String lastGoalString = "Последний гол: " + lastScored;
        String winnerString;
        String scoreString = new StringBuilder().append(milanGoals).toString() + " : " + new StringBuilder().append(realGoals).toString();

        if (milanGoals > realGoals)
        {
            winnerString = "Победитель: AC Milan";
        }
        else if (milanGoals < realGoals)
        {
            winnerString = "Победитель: Real Madrid";
        }
        else
        {
            winnerString = "Ничья";
        }

        score.setText(scoreString);
        infoWinner.setText(winnerString);
        infoLastGoal.setText(lastGoalString);
    }

    public myWindow()
    {
        setSize(600, 360);
        setLayout(new GridLayout(2, 3));

        score.setText("0 : 0");
        score.setFont(fnt);
        infoWinner.setText("Ничья ");
        infoLastGoal.setText("Последний гол: N/A");

        ImageIcon milan = new ImageIcon("milan.png");
        ImageIcon real = new ImageIcon("real.png");
        JButton RMA = new JButton("Забить гол");
        JButton ACM = new JButton("Забить гол");

        realLabel.setIcon(real);
        milanLabel.setIcon(milan);

        for (int i = 0; i < pnl.length; i++)
        {
            pnl[i] = new JPanel();
            add(pnl[i]);
        }

        RMA.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                realGoals++;
                refreshScore("Real Madrid");
            }
        });
        ACM.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                milanGoals++;
                refreshScore("AC Milan");
            }
        });

        JPanel tempPanel1 = new JPanel();
        JPanel tempPanel2 = new JPanel();
        JPanel tempPanel3 = new JPanel();
        JPanel tempPanel4 = new JPanel();
        JPanel tempPanel5 = new JPanel();
        JPanel tempPanel6 = new JPanel();

        pnl[0].add(milanLabel);
        pnl[1].setLayout(new GridLayout(2, 1));
        pnl[1].add(tempPanel6);
        pnl[1].add(tempPanel5);
        pnl[2].add(realLabel);
        pnl[3].add(ACM);

        // Дизайнерский костыль
        pnl[4].setLayout(new GridLayout(4, 1));
        pnl[4].add(tempPanel1);
        pnl[4].add(tempPanel2);
        pnl[4].add(tempPanel3);
        pnl[4].add(tempPanel4);

        tempPanel2.add(infoWinner);
        tempPanel3.add(infoLastGoal);
        tempPanel5.add(score);

        pnl[5].add(RMA);

    }
}

public class mainForm
{
    public static void main(String[] args)
    {
        new myWindow().setVisible(true);
    }
}
