package ru.mirea.lab12;

class Person
{
    private String fullName;
    public Person()
    {
        fullName = null;
    }
    public Person(String fullName)
    {
        this.fullName = fullName;
    }
    public String getFullName()
    {
        if (fullName != null)
        {
            return fullName;
        }
        else return "null";
    }
}

public class Task1 {
    public static void main(String[] args)
    {
        Person person1 = new Person("Claude Anderson");
        Person person2 = new Person();
        System.out.println(person1.getFullName());
        System.out.println(person2.getFullName());
    }
}
