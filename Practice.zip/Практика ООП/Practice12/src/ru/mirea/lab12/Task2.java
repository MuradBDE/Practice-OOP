package ru.mirea.lab12;

import java.util.StringTokenizer;

class Adress
{
    private String country;
    private String region;
    private String town;
    private String street;
    private String house;
    private String flat;
    public Adress(String fullAdress)
    {
        String[] temp = new String[6];
        temp = fullAdress.split(",");
        country = temp[0];
        region = temp[1];
        town = temp[2];
        street = temp[3];
        house = temp[4];
        flat = temp[5];
    }
    public Adress(String fullAdress, String token)
    {
        StringTokenizer tokenizer = new StringTokenizer(fullAdress, token);
        country = tokenizer.nextToken();
        region = tokenizer.nextToken();
        town = tokenizer.nextToken();
        street = tokenizer.nextToken();
        house = tokenizer.nextToken();
        flat = tokenizer.nextToken();
    }
    public String getTown(){
        return town;
    }

}

public class Task2 {
    public static void main(String[] args)
    {
        Adress adress1 = new Adress("country,region,town,street,block,flat");
        Adress adress2 = new Adress("country,region.town/street:block-flat", ",./:-");
        System.out.println(adress1.getTown());
        System.out.println(adress2.getTown());
    }
}
