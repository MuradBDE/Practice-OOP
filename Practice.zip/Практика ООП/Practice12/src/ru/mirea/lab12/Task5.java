package ru.mirea.lab12;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Task5
{
    public static void main(String[] args)
    {
        //C:\Users\magmu\Desktop\Учеба\ООП\Практика ООП\Practice12\test.txt
        Scanner scanner = new Scanner(System.in);
        String adress = scanner.nextLine();
        String sentence = "";
        try
        {
            FileReader reader = new FileReader(adress);
            int c;
            while ((c = reader.read()) != -1)
            {
                sentence += (char)c;
            }
            String[] splitted = sentence.split(" ");
            String newSentence = splitted[0];
            int counter = 1;
            while (counter != splitted.length)
            {
                for (int i = 0; i < splitted.length; i++)
                {
                    if(splitted[i].charAt(0) ==  newSentence.charAt(newSentence.length() - 1))
                    {
                        newSentence += " " + splitted[i];
                        counter++;
                    }
                }
            }

            System.out.println(newSentence);

        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
