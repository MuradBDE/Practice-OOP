package ru.mirea.Practice7;

public abstract class Deck
{
    public abstract void add(int _value);
    public abstract int remove();
    public abstract int length();
}
