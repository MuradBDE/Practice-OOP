package ru.mirea.Practice7;

import java.util.ArrayDeque;

public class DequeDeck extends Deck
{
    ArrayDeque<Integer> deck = new ArrayDeque<Integer>();

    public void add(int _value)
    {
        deck.addFirst(_value);
    }

    public int remove()
    {
        return deck.removeLast();
    }

    public int length()
    {
        return deck.size();
    }
}
