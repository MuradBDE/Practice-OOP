package ru.mirea.Practice7;

import java.util.Comparator;
import java.util.PriorityQueue;

public class QueueDeck extends Deck
{
    private Comparator<Integer> comparator = new Comparator<Integer>()
    {

        @Override
        public int compare(Integer o1, Integer o2)
        {
            return o2 - o1;
        }
    };
    private PriorityQueue<Integer> deck = new PriorityQueue<Integer>(comparator);
    public void add(int _value)
    {
        deck.add(_value);
    }
    public int remove()
    {
        return deck.remove();
    }
    public int length()
    {
        return deck.size();
    }
}
