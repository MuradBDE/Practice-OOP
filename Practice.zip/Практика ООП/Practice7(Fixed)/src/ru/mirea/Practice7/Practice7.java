package ru.mirea.Practice7;

import java.util.Scanner;

public class Practice7
{
    public static void input(Deck deck)
    {
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < 6; i++)
        {
            deck.add(scanner.nextInt());
        }
    }
    public static void main(String[] args)
    {
        Table table = new Table();
        Deck deck1, deck2;
        deck1 = new StackDeck(); deck2 = new StackDeck();
        //deck1 = new QueueDeck(); deck2 = new QueueDeck();
        //deck1 = new DequeDeck(); deck2 = new DequeDeck();
        //deck1 = new ListDeck(); deck2 = new ListDeck();

        input(deck1);
        input(deck2);
        table.play(deck1, deck2);
    }
}
