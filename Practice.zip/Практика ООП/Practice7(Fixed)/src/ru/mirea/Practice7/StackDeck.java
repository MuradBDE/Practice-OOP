package ru.mirea.Practice7;

import java.util.Stack;

public class StackDeck extends Deck
{
    private Stack<Integer> deck = new Stack<>();
    public void add(int _value)
    {
        invert();
        deck.push(_value);
        invert();
    }
    public int remove()
    {
        return deck.pop();
    }
    private void invert()
    {
        Stack<Integer> tempDeck = new Stack<Integer>();
        while (!deck.empty())
        {
            tempDeck.push(deck.pop());
        }
        deck = new Stack<Integer>();
        deck = tempDeck;
    }
    public int length()
    {
        return deck.size();
    }
}
