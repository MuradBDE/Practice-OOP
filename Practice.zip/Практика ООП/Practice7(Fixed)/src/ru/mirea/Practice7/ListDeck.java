package ru.mirea.Practice7;

import java.util.LinkedList;

public class ListDeck extends Deck
{
    private LinkedList<Integer> deck = new LinkedList<>();
    public void add(int _value)
    {
        deck.addFirst(_value);
    }
    public int remove()
    {
        return deck.removeLast();
    }
    public int length()
    {
        return deck.size();
    }
}
