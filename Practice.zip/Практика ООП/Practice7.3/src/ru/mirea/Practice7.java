package ru.mirea;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Scanner;
import java.util.LinkedList;
class Deck
{
    ArrayDeque<Integer> deck = new ArrayDeque<Integer>();
    public void add(int _value)
    {
        deck.addFirst(_value);
    }
    public int remove()
    {
        return deck.removeLast();
    }
    public void input()
    {
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < 6; i++)
        {
            deck.addFirst(scanner.nextInt());
        }
    }
    public int length()
    {
        return deck.size();
    }
}

public class Practice7
{
    public static void compare(Deck deck1, Deck deck2)
    {
        int card1 = deck1.remove();
        int card2 = deck2.remove();
        if (card1 > card2)
        {
            deck1.add(card1);
            deck1.add(card2);
        }
        else
        {
            deck2.add(card2);
            deck2.add(card1);
        }
    }
    public static void main(String[] args)
    {
        int attempts = 0;
        Deck firstDeck = new Deck();
        Deck secondDeck = new Deck();
        firstDeck.input();
        secondDeck.input();
        while (true)
        {
            if (firstDeck.length() == 0)
            {
                System.out.println("Second: " + attempts);
                break;
            }
            else if (secondDeck.length() == 0)
            {
                System.out.println("First: " + attempts);
                break;
            }
            else if (attempts == 106)
            {
                System.out.println("botva");
                break;
            }
            compare(firstDeck, secondDeck);
            attempts++;
        }
    }
}
