package ru.mirea;

import java.util.Stack;
import java.util.Scanner;
class Deck
{
    Stack<Integer> deck = new Stack<Integer>();
    public void push(int _value)
    {
        deck.push(_value);
    }
    public int pop()
    {
        return deck.pop();
    }
    public void invert()
    {
        Stack<Integer> tempDeck = new Stack<Integer>();
        while (!deck.empty())
        {
            tempDeck.push(deck.pop());
        }
        deck = new Stack<Integer>();
        deck = tempDeck;
    }
    public void input()
    {
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < 6; i++)
        {
            deck.push(scanner.nextInt());
        }
    }
    public int length()
    {
        return deck.size();
    }
}

public class Practice71
{
    public static void compare(Deck deck1, Deck deck2)
    {
        int card1 = deck1.pop();
        int card2 = deck2.pop();
        if (card1 > card2)
        {
            deck1.invert();
            deck1.push(card1);
            deck1.push(card2);
            deck1.invert();
        }
        else
        {
            deck2.invert();
            deck2.push(card2);
            deck2.push(card1);
            deck2.invert();
        }
    }
    public static void main(String[] args)
    {
        int attempts = 0;
        Deck firstDeck = new Deck();
        Deck secondDeck = new Deck();
        firstDeck.input();
        secondDeck.input();
        while (true)
        {
            if (firstDeck.length() == 0)
            {
                System.out.println("Second: " + attempts);
                break;
            }
            if (secondDeck.length() == 0)
            {
                System.out.println("First: " + attempts);
                break;
            }
            if (attempts == 106)
            {
                System.out.println("botva");
                break;
            }
            compare(firstDeck, secondDeck);
            attempts++;
        }
    }
}
