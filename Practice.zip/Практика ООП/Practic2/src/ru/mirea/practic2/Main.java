package ru.mirea.practic2;

class Author
{
    private String name;
    private String email;
    private char gender;
    public Author(String _name, String _email, char _gender)
    {
        name = _name;
        email = _email;
        gender = _gender;
    }
    public String getName()
    {
        return name;
    }
    public String getEmail()
    {
        return email;
    }
    public char getGender()
    {
        return gender;
    }
    public void setEmail(String _email)
    {
        email = _email;
    }

    @Override
    public String toString()
    {
        return "Информация об авторе: \n" + name + '\n' + email + '\n' + "Пол: " + gender;
    }
}

class Ball
{
    private double x;
    private double y;
    public Ball()
    {
        x = 0.0;
        y = 0.0;
    }
    public Ball (double _x, double _y)
    {
        x = _x;
        y = _y;
    }
    public void setX(double _x)
    {
        x = _x;
    }
    public void setY(double _y)
    {
        y = _y;
    }
    public double getX()
    {
        return x;
    }
    private double getY()
    {
        return y;
    }
    public void setXY(double _x, double _y)
    {
        x = _x;
        y = _y;
    }
    public void move(double xDisp, double yDisp)
    {
        x += xDisp;
        y += yDisp;
    }
    @Override
    public String toString()
    {
        return "Координаты шара: {" + x + "; " + y + "}\n";
    }
}

public class Main
{
    public static void main(String[] args)
    {
        Author author1 = new Author("Трэвис Скотт", "yunglaflame@gmail.com", 'm');
        System.out.println(author1);
        Ball ball1 = new Ball(12.3, 14.2);
        System.out.println(ball1);
    }
}
