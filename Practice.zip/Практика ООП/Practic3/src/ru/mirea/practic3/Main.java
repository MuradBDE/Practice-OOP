package ru.mirea.practic3;


// Упражнение 1-3
abstract class Shape
{
    protected String colour;
    protected boolean filled;

    public Shape()
    {
        colour = "";
        filled = false;
    }

    public Shape(String _colour, boolean _filled)
    {
        colour = _colour;
        filled = _filled;
    }

    public String getColour()
    {
        return colour;
    }

    public void setColour(String _colour)
    {
        colour = _colour;
    }

    public boolean isFilled()
    {
        return filled;
    }

    public void setFilled(boolean _filled)
    {
        filled = _filled;
    }

    public abstract double getPerimeter();

    public abstract double getArea();

    public abstract String toString();
}

class Circle extends Shape
{
    protected double radius;

    public Circle()
    {
        radius = 0;
    }

    public Circle(double _radius)
    {
        radius = _radius;
    }

    public Circle(double _radius, String _colour, boolean _filled)
    {
        radius = _radius;
        colour = _colour;
        filled = _filled;
    }

    public void setRadius(double _radius)
    {
        radius = _radius;
    }

    public double getRadius()
    {
        return radius;
    }

    @Override
    public double getArea()
    {
        return 3.1415926 * radius * radius;
    }

    @Override
    public double getPerimeter()
    {
        return 2 * 3.1415926 * radius;
    }

    @Override
    public String toString()
    {
        return "Информация о шаре:\n" + "Цвет: " + colour + "\nЗакрашенный: " + filled + "\nРадиус: " + getRadius() + "\nПлощадь: " + getArea() + "\nПериметр: " + getPerimeter();
    }
}

class Rectangle extends Shape
{
    protected double width;
    protected double length;

    public Rectangle()
    {
        width = 0;
        length = 0;
    }

    public Rectangle(double _width, double _length)
    {
        width = _width;
        length = _length;
    }

    public Rectangle(double _width, double _length, String _colour, boolean _filled)
    {
        width = _width;
        length = _length;
        colour = _colour;
        filled = _filled;
    }

    public double getWidth()
    {
        return width;
    }

    public double getLength()
    {
        return length;
    }

    public void setWidth(double _width)
    {
        width = _width;
    }

    public void setLength(double _length)
    {
        length = _length;
    }

    ////////////
    ////////////
    @Override
    public double getPerimeter()
    {
        return 2.0 * (length + width);
    }

    @Override
    public double getArea()
    {
        return length * width;
    }

    @Override
    public String toString()
    {
        return "Информация о прямоугольнике:\nДлина: " + length + "\nШирина: " + width + "\nЗакрашенный: " + filled + "\nЦвет: " + colour + "\nПлощадь: " + getArea() + "\nПериметр: " + getPerimeter();
    }
}

class Square extends Rectangle
{
    public Square()
    {
        length = 0;
        width = 0;
    }

    public Square(double side)
    {
        length = side;
        width = side;
    }

    public Square(double side, String _colour, boolean _filled)
    {
        length = side;
        width = side;
        colour = _colour;
        filled = _filled;
    }

    @Override
    public void setLength(double side)
    {
        length = side;
        width = side;
    }

    @Override
    public void setWidth(double side)
    {
        length = side;
        width = side;
    }

    @Override
    public String toString()
    {
        return "Квадрат со стороной: " + length + "\nЗакрашенный: " + filled + "\nЦвет: " + colour + "\nПлощадь: " + getArea() + "\nПериметр: " + getPerimeter();
    }
}

// Упражнение 4
interface Movable
{
    public void MoveUp();

    public void MoveDown();

    public void MoveLeft();

    public void MoveRight();
}

class MovablePoint implements Movable
{
    protected int x;
    protected int y;
    protected int xSpeed;
    protected int ySpeed;

    public MovablePoint()
    {
        x = 0;
        y = 0;
        xSpeed = 0;
        ySpeed = 0;
    }

    public MovablePoint(int _x, int _y, int _xSpeed, int _ySpeed)
    {
        x = _x;
        y = _y;
        xSpeed = _xSpeed;
        ySpeed = _ySpeed;
    }

    public void MoveUp()
    {
        y += ySpeed;
    }

    public void MoveDown()
    {
        y -= ySpeed;
    }

    public void MoveLeft()
    {
        x -= xSpeed;
    }

    public void MoveRight()
    {
        x += xSpeed;
    }

    public int getXSpeed()
    {
        return xSpeed;
    }

    public int getYSpeed()
    {
        return ySpeed;
    }

    @Override
    public String toString()
    {
        return "Точка с координатами: " + x + "; " + y + "\nСкорость: " + xSpeed + "; " + ySpeed;
    }
}

class MovableCircle implements Movable
{
    private int radius;
    private MovablePoint center;

    public MovableCircle(int _radius, MovablePoint _center)
    {
        center = _center;
        radius = _radius;
    }

    public void MoveUp()
    {
        center.MoveUp();
    }

    public void MoveDown()
    {
        center.MoveDown();
    }

    public void MoveLeft()
    {
        center.MoveLeft();
    }

    public void MoveRight()
    {
        center.MoveRight();
    }

    @Override
    public String toString()
    {
        return "Круг с радиусом: " + radius + "\nИнформация о центре:\n" + center;
    }
}

// Упражнение 5
class MovableRectangle implements Movable
{
    private MovablePoint topLeft;
    private MovablePoint bottomRight;

    public MovableRectangle(int x1, int y1, int x2, int y2, int xSpeed, int ySpeed)
    {
        topLeft = new MovablePoint(x1, y1, xSpeed, ySpeed);
        bottomRight = new MovablePoint(x2, y2, xSpeed, ySpeed);
    }

    public void MoveUp()
    {
        topLeft.MoveUp();
        bottomRight.MoveUp();
    }

    public void MoveDown()
    {
        topLeft.MoveDown();
        bottomRight.MoveDown();
    }

    public void MoveLeft()
    {
        topLeft.MoveLeft();
        bottomRight.MoveLeft();
    }

    public void MoveRight()
    {
        topLeft.MoveRight();
        bottomRight.MoveRight();
    }

    @Override
    public String toString()
    {
        return "Прямоугольник с точками:\n" + "Верхняя точка: " + topLeft + "\nНижняя точка: " + bottomRight;
    }
}

public class Main
{
    public static void main(String[] args)
    {
        // Упражнения 1-3
        System.out.println("\nУпражнения 1-3 \n");
        Shape circle1 = new Circle(12, "RED", true);
        Shape rectangle1 = new Rectangle(14, 12, "RED", true);
        Shape square1 = new Square(12, "BLUE", true);
        System.out.println(circle1);
        System.out.println(rectangle1);
        System.out.println(square1);
        // Упражнение 4
        System.out.println("\nУпражнение 4 \n");
        Movable center = new MovablePoint(2, 4, 1, 1);
        Movable circle = new MovableCircle(12, (MovablePoint) center);
        System.out.println(circle);
        circle.MoveDown();
        circle.MoveRight();
        System.out.println(circle);
        // Упражнение 5
        System.out.println("\nУпражнение 5 \n");
        MovableRectangle rectangle = new MovableRectangle(5, 5, 2, 3, 1, 1);
        System.out.println(rectangle);
    }
}
