package ru.mirea.practic1;

class Dog
{
    private int height;
    private int weight;
    public Dog (int _weight, int _height)
    {
        height = _height;
        weight = _weight;
    }
    public void bark()
    {
        System.out.println("Bark!");
    }
    public String toString()
    {
        return "Рост: " + height + "\nВес: " + weight + '\n';
    }
}

public class Main
{
    public static class Ball
    {
        private int radius;
        private String colour;
        public Ball(int _radius, String _colour)
        {
            radius = _radius;
            colour = _colour;
        }
        public double size()
        {
            return radius*radius*radius*3.1415926*4/3;
        }
        public String toString()
        {
            return "Цвет: " + colour + "\nОбъем: " + size() + '\n';
        }

    }
    public static class Book
    {
        public String name;
        public String author;
        public int pages;
        public Book(String _name, String _author, int _pages)
        {
            name = _name;
            author = _author;
            pages = _pages;
        }
        public String toString()
        {
            return "Название книги: " + name + "\nАвтор: " + author + "\nКолличество странц: " + pages + '\n';
        }
    }
    public static void main(String[] args)
    {
        Dog dog1 = new Dog(12, 14);
        dog1.bark();
        System.out.println(dog1);
        Ball ball1 = new Ball(12, "Red");
        System.out.println(ball1);
        Book book1 = new Book("Море и старик", "Хэминг Эрнестуей", 40);
        System.out.println(book1);
    }
}
