package ru.mirea;

import java.util.Scanner;


public class Recursion
{
    // Рекурсия для задания 17 варианта
    public static int recursion17(int maxNumber)
    {
        Scanner scanner = new Scanner(System.in);
        int max = maxNumber;
        int number;
        number = scanner.nextInt();
        if (number != 0)
        {
            if (number >= max)
            {
                max = number;
            }
            max = recursion17(max);
        }
        return max;
    }

    // Рекурсия для задания 1 варианта
    public static void recursion1(int number1, int number2)
    {
        for (int i = number2; i < number1; i++)
        {
            System.out.print(number1 - number2);
        }
        System.out.print(' ');
        if (number2 > 0)
        {
            recursion1(number1, number2 - 1);
        }
    }

    // Рекурсия для задания 2 варианта
    public static void recursion2(int number1, int number2)
    {
        System.out.print(number1 - number2);
        System.out.print(' ');
        if (number2 > 0)
        {
            recursion2(number1, number2 - 1);
        }
    }

    // Рекурсия для задания 3 варианта
    public static void recursion31(int number1, int number2)
    {
        if (number1 <= number2)
        {
            System.out.print(number1);
            System.out.print(' ');
            recursion31(number1 + 1, number2);
        }
    }
    public static void recursion32(int number1, int number2)
    {
        if(number1 >= number2)
        {
            System.out.print(number1);
            System.out.print(' ');
            recursion32(number1 - 1, number2);
        }
    }


    public static void var17()
    {
        System.out.println("Введите последовательность: ");
        System.out.println(recursion17(0));
    }

    public static void var1()
    {
        System.out.print("Введите максимальное число последовательности: ");
        int number;
        Scanner scanner = new Scanner(System.in);
        number = scanner.nextInt();
        recursion1(number, number - 1);
    }

    public static void var2()
    {
        System.out.print("Введите максимальное число последовательности: ");
        int number;
        Scanner scanner = new Scanner(System.in);
        number = scanner.nextInt();
        recursion2(number, number - 1);
    }

    public static void var3()
    {
        System.out.print("Введите два числа: ");
        int number1, number2;
        Scanner scanner = new Scanner(System.in);
        number1 = scanner.nextInt();
        number2 = scanner.nextInt();
        if(number1 > number2)
        {
            recursion32(number1, number2);
        }
        else
        {
            recursion31(number1, number2);
        }
    }

    public static void main(String[] args)
    {
        var17();
        //var1();
        //var2();
        //var3();
    }
}
